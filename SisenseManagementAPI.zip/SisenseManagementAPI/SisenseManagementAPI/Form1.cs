﻿using Newtonsoft.Json.Linq;
using RestClientDotNet;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace SisenseManagementAPI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            string token = getToken();
            //Console.WriteLine(token);

            string userID = getUserID("erin@le-intl.com", token);
            //Console.WriteLine(userID);

            string Dashboard_ID= "58a6b1daeb5a79dc71000142";

             JArray curr_shares = getDashboardShares(Dashboard_ID, token);
            //Console.WriteLine(curr_shares.ToString());

            addShares(Dashboard_ID, curr_shares, userID, "user", "view", false, token);

            try
            {
                //5af4f52ef0a34127d023fb04 dashboard id

                downloadDashBoardPng("59707946e3bf1b486a000013", "59707946e3bf1b486a000013.png", 2500);
                //downloadImage("5af4f52ef0a34127d023fb04", "5af4f52ef0a34127d023fb07", 2500, 1122);
            }
            catch (Exception ex) { }
        }

        private static readonly HttpClient client = new HttpClient();

        /*static string getToken()
        {
            //var client = new RestClientDotNet.RestClient("http://kpi.le-intl.asia:8081/api/v1/authentication/login");
            var client = new RestSharp.RestClient("http://kpi.le-intl.asia:8081/api/v1/authentication/login");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("accept", "application/json");
            request.AddHeader("content-type", "application/x-www-form-urlencoded");

            request.AddParameter("username", "<Admin User Email>");
            request.AddParameter("password", "<Admin User Password>");

            IRestResponse response = client.Execute(request);

            JObject obj = JObject.Parse(response.Content);

            return obj.GetValue("access_token").ToString();

        }

        private void Get()
        {
            //string id_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiNTgwODgyOTAyZjk5NmE1MjU0NGVkODRkIiwiYXBpU2VjcmV0IjoiZWY1M2M4OGMtZDZlMC1lNTQ5LWIzOTktNDIxMzBhYmQ3ZDM0IiwiaWF0IjoxNTU3OTc3NDMyfQ.3ZCHvvAA0b8tzgTo2m-ir749-zL0mZQq5o82JYWkflM";
            //string token = "Bearer" + id_token;

            string token = getToken();
            Console.WriteLine(token);

            string userID = "580882902f996a52544ed84d";//getUserID("<User Email>", token);
            Console.WriteLine(userID);

            JArray curr_shares = getDashboardShares("<Dashboard ID>", token);
            Console.WriteLine(curr_shares.ToString());

            addShares("<Dashboard ID>", curr_shares, userID, "user", "view", false, token);
        }*/

        static string getToken()
        {
            var client = new RestSharp.RestClient("http://kpi.le-intl.asia:8081/api/v1/authentication/login");//("http://localhost:8081/api/v1/authentication/login");
            var request = new RestSharp.RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("accept", "application/json");
            request.AddHeader("content-type", "application/x-www-form-urlencoded");

            request.AddParameter("username", "erin@le-intl.com");
            request.AddParameter("password", "tyu678!@");


            IRestResponse response = client.Execute(request);

            JObject obj = JObject.Parse(response.Content);


            return obj.GetValue("access_token").ToString();

        }

        static string getUserID(string userName, string token)
        {

            var client = new RestSharp.RestClient("http://kpi.le-intl.asia:8081/api/users/" + userName);
            var request = new RestSharp.RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("authorization", "Bearer " + token);
            request.AddHeader("accept", "application/json");
            IRestResponse response = client.Execute(request);

            JObject obj = JObject.Parse(response.Content);

            return obj.GetValue("_id").ToString();
        }

        static JArray getDashboardShares(string dashboardID, string token)
        {
            var client = new RestSharp.RestClient("http://kpi.le-intl.asia:8081/api/v1/dashboards/" + dashboardID + "/shares");
            var request = new RestSharp.RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("authorization", "Bearer " + token);
            request.AddHeader("accept", "application/json");
            IRestResponse response = client.Execute(request);

            JArray arr = JArray.Parse(response.Content);

            return arr;
        }

        static JArray addShares(string dashboardID, JArray curr_shares, string userID, string type, string role, bool subscribe, string token)
        {
            var client = new RestSharp.RestClient("http://kpi.le-intl.asia:8081/api/v1/dashboards/" + dashboardID);
            var request = new RestSharp.RestRequest(Method.PATCH);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("authorization", "Bearer " + token);
            request.AddHeader("accept", "application/json");
            request.AddHeader("content-type", "application/json");


            string json_str = "{\"shareId\": \"" + userID + "\",\"type\": \"user\", \"rule\": \"view\", \"subscribe\": false}";
            JObject new_obj = JObject.Parse(json_str);

            curr_shares.Add(new_obj);

            string new_str = "{\"shares\":" + curr_shares.ToString() + "}";
            JObject new_shares = JObject.Parse(new_str);
            request.AddParameter("application/json", new_shares, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            return curr_shares;
        }

        
        static void downloadImage(string dashboardID, string widgetID,int width, int heigh)
        {
            var client = new RestSharp.RestClient("http://kpi.le-intl.asia:8081/api/v1/dashboards/"+ dashboardID + "/widgets/"+ widgetID + "/export/png?width="+ width + "&height="+ heigh + "%22%20-H%20%22accept:%20image/png%22%20-H%20%22authorization:%20Bearer%20eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiNTgwODgyOTAyZjk5NmE1MjU0NGVkODRkIiwiYXBpU2VjcmV0IjoiZWY1M2M4OGMtZDZlMC1lNTQ5LWIzOTktNDIxMzBhYmQ3ZDM0IiwiaWF0IjoxNTU3OTc5OTA3fQ.TCpR7QuT1osDXRBzVE4OqBctgsxm7Goq_sZ7lS2z7q0");
            var request = new RestSharp.RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("accept-encoding", "gzip, deflate");
            request.AddHeader("cookie", ".ASPXANONYMOUS=v7m4u_c_1QEkAAAAZTlhODMyN2MtMDNkZS00NDIxLThiNjQtNWNiNWI2ZTZhNTdks0VBsnq_ajrrCnD8I1ld526AAEA-LUrv0UHvSXDM1mM1");
            request.AddHeader("Host", "kpi.le-intl.asia:8081");
            request.AddHeader("Postman-Token", "2b3a5eb4-77dd-4071-bdff-da4fc34a3971,7a94ec9f-cdf8-4497-9285-345a4fc24326");
            request.AddHeader("Cache-Control", "no-cache");
            request.AddHeader("Accept", "*/*");
            request.AddHeader("User-Agent", "PostmanRuntime/7.11.0");
            request.AddHeader("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiNTgwODgyOTAyZjk5NmE1MjU0NGVkODRkIiwiYXBpU2VjcmV0IjoiZWY1M2M4OGMtZDZlMC1lNTQ5LWIzOTktNDIxMzBhYmQ3ZDM0IiwiaWF0IjoxNTU3OTc5OTA3fQ.TCpR7QuT1osDXRBzVE4OqBctgsxm7Goq_sZ7lS2z7q0");
            IRestResponse response = client.Execute(request);

            //Byte[] image = response.Content;
            File.WriteAllBytes(Path.Combine("D:\\", "poster-got.png"), response.RawBytes);

        }


        static void downloadPDF(string dashboardID,string fileName, string papersize, string paperOrientation /*portrait/landscape*/)//59f85678a5c98af4dad7eca8   //   58a6b1daeb5a79dc71000142
        {
            var client = new RestSharp.RestClient("http://kpi.le-intl.asia:8081/api/v1/dashboards/"+ dashboardID + "/export/pdf?paperFormat="+ papersize + "&paperOrientation="+ paperOrientation + "&layout=asis&includeTitle=true&includeFilters=true&includeDs=true&showTitle=false&showFooter=false&titleSize=medium&titlePosition=flex-start");
            var request = new RestSharp.RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("accept-encoding", "gzip, deflate");
            request.AddHeader("cookie", ".ASPXANONYMOUS=v7m4u_c_1QEkAAAAZTlhODMyN2MtMDNkZS00NDIxLThiNjQtNWNiNWI2ZTZhNTdks0VBsnq_ajrrCnD8I1ld526AAEA-LUrv0UHvSXDM1mM1");
            request.AddHeader("Host", "kpi.le-intl.asia:8081");
            request.AddHeader("Postman-Token", "ea2c8375-88ac-4751-9956-e12cfc9b2fc3,02371cfd-701e-47d8-933e-afd94b15a09c");
            request.AddHeader("Cache-Control", "no-cache");
            request.AddHeader("Accept", "*/*");
            request.AddHeader("User-Agent", "PostmanRuntime/7.11.0");
            request.AddHeader("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiNTgwODgyOTAyZjk5NmE1MjU0NGVkODRkIiwiYXBpU2VjcmV0IjoiZWY1M2M4OGMtZDZlMC1lNTQ5LWIzOTktNDIxMzBhYmQ3ZDM0IiwiaWF0IjoxNTU3OTc5OTA3fQ.TCpR7QuT1osDXRBzVE4OqBctgsxm7Goq_sZ7lS2z7q0");
            IRestResponse response = client.Execute(request);

            File.WriteAllBytes(Path.Combine("D:\\", fileName), response.RawBytes);
        }


        static void downloadDashBoardPng(string dashboardID, string fileName, int width /*portrait/landscape*/)//59f85678a5c98af4dad7eca8   //   58a6b1daeb5a79dc71000142
        {
            var client = new RestSharp.RestClient("http://kpi.le-intl.asia:8081/api/v1/dashboards/"+ dashboardID + "/export/png?includeTitle=true&includeFilters=true&includeDs=true&width="+ width + "");
            var request = new RestSharp.RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("accept-encoding", "gzip, deflate");
            request.AddHeader("cookie", ".ASPXANONYMOUS=v7m4u_c_1QEkAAAAZTlhODMyN2MtMDNkZS00NDIxLThiNjQtNWNiNWI2ZTZhNTdks0VBsnq_ajrrCnD8I1ld526AAEA-LUrv0UHvSXDM1mM1");
            request.AddHeader("Host", "kpi.le-intl.asia:8081");
            request.AddHeader("Postman-Token", "ea2c8375-88ac-4751-9956-e12cfc9b2fc3,02371cfd-701e-47d8-933e-afd94b15a09c");
            request.AddHeader("Cache-Control", "no-cache");
            request.AddHeader("Accept", "*/*");
            request.AddHeader("User-Agent", "PostmanRuntime/7.11.0");
            request.AddHeader("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiNTgwODgyOTAyZjk5NmE1MjU0NGVkODRkIiwiYXBpU2VjcmV0IjoiZWY1M2M4OGMtZDZlMC1lNTQ5LWIzOTktNDIxMzBhYmQ3ZDM0IiwiaWF0IjoxNTU3OTc5OTA3fQ.TCpR7QuT1osDXRBzVE4OqBctgsxm7Goq_sZ7lS2z7q0");
            IRestResponse response = client.Execute(request);
            // chỉ dùng được cho dashboard không plug in với dashboard khác
            //https://support.sisense.com/hc/en-us/articles/230650728-Error-exporting-to-PDF

            File.WriteAllBytes(Path.Combine("D:\\", fileName), response.RawBytes);
        }
    }
}
